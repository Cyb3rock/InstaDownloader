# Production Implementation Guide

This guide shows you how to implement a production-ready Instagram downloader with real API integration.

## 🎯 Option 1: RapidAPI Integration (Recommended for Beginners)

### Step 1: Sign Up and Get API Key

1. Go to https://rapidapi.com
2. Create an account
3. Subscribe to "Instagram Downloader" API
4. Copy your API key from the dashboard

### Step 2: Update InstagramApi.kt

```kotlin
package com.instadownloader.network

import com.instadownloader.models.MediaInfo
import com.instadownloader.models.MediaType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class InstagramApi {
    
    private val API_KEY = "YOUR_RAPIDAPI_KEY_HERE" // Replace with your key
    private val API_HOST = "instagram-downloader-download-instagram-videos-stories.p.rapidapi.com"
    private val API_URL = "https://$API_HOST"
    
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()
    
    suspend fun fetchMediaInfo(instagramUrl: String): MediaInfo {
        return withContext(Dispatchers.IO) {
            val request = Request.Builder()
                .url("$API_URL/index?url=$instagramUrl")
                .get()
                .addHeader("X-RapidAPI-Key", API_KEY)
                .addHeader("X-RapidAPI-Host", API_HOST)
                .build()
            
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    throw Exception("API Error: ${response.code}")
                }
                
                val body = response.body?.string() ?: throw Exception("Empty response")
                parseApiResponse(body, instagramUrl)
            }
        }
    }
    
    private fun parseApiResponse(jsonString: String, originalUrl: String): MediaInfo {
        val json = JSONObject(jsonString)
        
        val mediaType = detectMediaType(originalUrl)
        val downloadUrls = mutableMapOf<String, String>()
        val availableQualities = mutableListOf<String>()
        
        // Parse video URLs (API response structure may vary)
        if (json.has("video_url")) {
            val videoUrl = json.getString("video_url")
            downloadUrls["1080p"] = videoUrl
            availableQualities.add("1080p")
        }
        
        // Some APIs provide multiple qualities
        if (json.has("qualities")) {
            val qualities = json.getJSONArray("qualities")
            for (i in 0 until qualities.length()) {
                val quality = qualities.getJSONObject(i)
                val resolution = quality.getString("quality")
                val url = quality.getString("url")
                downloadUrls[resolution] = url
                availableQualities.add(resolution)
            }
        }
        
        val thumbnailUrl = if (json.has("thumbnail")) {
            json.getString("thumbnail")
        } else ""
        
        return MediaInfo(
            type = mediaType,
            downloadUrls = downloadUrls,
            availableQualities = availableQualities.sorted(),
            thumbnailUrl = thumbnailUrl,
            isVideo = true
        )
    }
    
    private fun detectMediaType(url: String): MediaType {
        return when {
            url.contains("/reel/") -> MediaType.REEL
            url.contains("/stories/") -> MediaType.STORY
            url.contains("/p/") -> MediaType.POST
            else -> MediaType.POST
        }
    }
}
```

## 🎯 Option 2: Instagram Graph API (Official)

### Requirements
- Facebook Developer Account
- Instagram Business/Creator Account
- App Review Approval

### Step 1: Create Facebook App

1. Go to https://developers.facebook.com
2. Create a new app
3. Add Instagram Basic Display product
4. Configure OAuth redirect URIs
5. Get App ID and App Secret

### Step 2: Implementation

```kotlin
class InstagramGraphApi {
    
    private val APP_ID = "YOUR_FACEBOOK_APP_ID"
    private val APP_SECRET = "YOUR_APP_SECRET"
    private val REDIRECT_URI = "https://yourapp.com/auth/callback"
    
    // Step 1: Get Authorization Code
    fun getAuthorizationUrl(): String {
        return "https://api.instagram.com/oauth/authorize" +
               "?client_id=$APP_ID" +
               "&redirect_uri=$REDIRECT_URI" +
               "&scope=user_profile,user_media" +
               "&response_type=code"
    }
    
    // Step 2: Exchange code for access token
    suspend fun getAccessToken(code: String): String {
        return withContext(Dispatchers.IO) {
            val formBody = FormBody.Builder()
                .add("client_id", APP_ID)
                .add("client_secret", APP_SECRET)
                .add("grant_type", "authorization_code")
                .add("redirect_uri", REDIRECT_URI)
                .add("code", code)
                .build()
            
            val request = Request.Builder()
                .url("https://api.instagram.com/oauth/access_token")
                .post(formBody)
                .build()
            
            client.newCall(request).execute().use { response ->
                val json = JSONObject(response.body?.string() ?: "")
                json.getString("access_token")
            }
        }
    }
    
    // Step 3: Get media info
    suspend fun getMediaInfo(mediaId: String, accessToken: String): MediaInfo {
        return withContext(Dispatchers.IO) {
            val request = Request.Builder()
                .url("https://graph.instagram.com/$mediaId?fields=id,media_type,media_url,thumbnail_url,permalink&access_token=$accessToken")
                .get()
                .build()
            
            client.newCall(request).execute().use { response ->
                val json = JSONObject(response.body?.string() ?: "")
                // Parse and return MediaInfo
                parseGraphApiResponse(json)
            }
        }
    }
}
```

## 🎯 Option 3: Custom Backend Server (Most Control)

### Python Backend Example (Using Instaloader)

Create a Flask server:

```python
from flask import Flask, request, jsonify
import instaloader
import json

app = Flask(__name__)
L = instaloader.Instaloader()

@app.route('/api/fetch', methods=['POST'])
def fetch_media():
    try:
        url = request.json['url']
        shortcode = extract_shortcode(url)
        
        # Get post
        post = instaloader.Post.from_shortcode(L.context, shortcode)
        
        # Get video URL
        if post.is_video:
            video_url = post.video_url
        else:
            video_url = None
        
        response = {
            'type': 'VIDEO' if post.is_video else 'IMAGE',
            'video_url': video_url,
            'thumbnail_url': post.url,
            'caption': post.caption,
            'owner': post.owner_username,
            'qualities': {
                '1080p': video_url,  # Instagram typically serves one quality
            }
        }
        
        return jsonify(response)
        
    except Exception as e:
        return jsonify({'error': str(e)}), 400

def extract_shortcode(url):
    # Extract shortcode from Instagram URL
    patterns = ['/p/', '/reel/', '/tv/']
    for pattern in patterns:
        if pattern in url:
            return url.split(pattern)[1].split('/')[0]
    raise ValueError('Invalid Instagram URL')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
```

### Android Client for Custom Backend

```kotlin
class CustomBackendApi {
    
    private val BACKEND_URL = "https://your-server.com/api"
    
    suspend fun fetchMediaInfo(instagramUrl: String): MediaInfo {
        return withContext(Dispatchers.IO) {
            val json = JSONObject().put("url", instagramUrl)
            val body = json.toString().toRequestBody("application/json".toMediaType())
            
            val request = Request.Builder()
                .url("$BACKEND_URL/fetch")
                .post(body)
                .build()
            
            client.newCall(request).execute().use { response ->
                val responseBody = response.body?.string() ?: ""
                parseBackendResponse(responseBody)
            }
        }
    }
}
```

## 🎯 Option 4: Web Scraping (Advanced, Use Cautiously)

**⚠️ Warning**: Web scraping may violate Instagram's ToS. Use only for educational purposes.

```kotlin
class InstagramScraper {
    
    private val USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
    
    suspend fun fetchMediaInfo(instagramUrl: String): MediaInfo {
        return withContext(Dispatchers.IO) {
            val html = fetchPageHtml(instagramUrl)
            val videoUrl = extractVideoUrl(html)
            val thumbnailUrl = extractThumbnailUrl(html)
            
            MediaInfo(
                type = detectMediaType(instagramUrl),
                downloadUrls = mapOf("1080p" to videoUrl),
                availableQualities = listOf("1080p"),
                thumbnailUrl = thumbnailUrl,
                isVideo = true
            )
        }
    }
    
    private fun fetchPageHtml(url: String): String {
        val request = Request.Builder()
            .url(url)
            .addHeader("User-Agent", USER_AGENT)
            .build()
        
        client.newCall(request).execute().use { response ->
            return response.body?.string() ?: ""
        }
    }
    
    private fun extractVideoUrl(html: String): String {
        // Method 1: Look for video URL in JSON data
        val jsonRegex = """window\._sharedData = (.*?);</script>""".toRegex()
        val match = jsonRegex.find(html)
        
        if (match != null) {
            val json = JSONObject(match.groupValues[1])
            // Navigate JSON structure to find video_url
            // Structure varies, typically in entry_data.PostPage
            return navigateToVideoUrl(json)
        }
        
        // Method 2: Look for video tag
        val videoRegex = """<video[^>]*src="([^"]+)"""".toRegex()
        val videoMatch = videoRegex.find(html)
        
        return videoMatch?.groupValues?.get(1) ?: throw Exception("Video URL not found")
    }
    
    private fun navigateToVideoUrl(json: JSONObject): String {
        try {
            val postPage = json.getJSONObject("entry_data")
                .getJSONArray("PostPage")
                .getJSONObject(0)
            
            val media = postPage.getJSONObject("graphql")
                .getJSONObject("shortcode_media")
            
            return media.getString("video_url")
        } catch (e: Exception) {
            throw Exception("Failed to parse video URL from page data")
        }
    }
}
```

## 📊 Quality Resolution Mapping

Different APIs provide different quality options. Here's how to handle them:

```kotlin
fun mapQualityToStandard(apiQuality: String): String {
    return when {
        apiQuality.contains("4k", ignoreCase = true) || 
        apiQuality.contains("2160", ignoreCase = true) -> "4K"
        
        apiQuality.contains("1080", ignoreCase = true) ||
        apiQuality.contains("full hd", ignoreCase = true) -> "1080p"
        
        apiQuality.contains("720", ignoreCase = true) ||
        apiQuality.contains("hd", ignoreCase = true) -> "720p"
        
        apiQuality.contains("480", ignoreCase = true) ||
        apiQuality.contains("sd", ignoreCase = true) -> "480p"
        
        else -> "1080p" // Default
    }
}

fun selectBestQualityUrl(urls: Map<String, String>): String {
    val priorityOrder = listOf("4K", "1080p", "720p", "480p")
    
    for (quality in priorityOrder) {
        if (urls.containsKey(quality)) {
            return urls[quality]!!
        }
    }
    
    return urls.values.first()
}
```

## 🔒 Security Best Practices

### 1. Secure API Keys

Never hardcode API keys. Use BuildConfig:

```gradle
// In app/build.gradle
android {
    defaultConfig {
        buildConfigField "String", "RAPID_API_KEY", "\"${project.findProperty('RAPID_API_KEY')}\""
    }
}
```

Create `gradle.properties`:
```properties
RAPID_API_KEY=your_actual_key_here
```

Use in code:
```kotlin
private val API_KEY = BuildConfig.RAPID_API_KEY
```

### 2. Certificate Pinning

```kotlin
val certificatePinner = CertificatePinner.Builder()
    .add("instagram.com", "sha256/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=")
    .build()

val client = OkHttpClient.Builder()
    .certificatePinner(certificatePinner)
    .build()
```

### 3. Rate Limiting

```kotlin
class RateLimiter(private val maxRequests: Int, private val timeWindowMs: Long) {
    private val timestamps = mutableListOf<Long>()
    
    suspend fun acquire() {
        val now = System.currentTimeMillis()
        timestamps.removeAll { it < now - timeWindowMs }
        
        if (timestamps.size >= maxRequests) {
            val waitTime = timestamps.first() + timeWindowMs - now
            delay(waitTime)
        }
        
        timestamps.add(now)
    }
}

// Usage
private val rateLimiter = RateLimiter(maxRequests = 10, timeWindowMs = 60_000)

suspend fun fetchMediaInfo(url: String): MediaInfo {
    rateLimiter.acquire()
    // Make API request
}
```

## 🧪 Testing Your Implementation

### Test URLs

```kotlin
val testUrls = listOf(
    "https://www.instagram.com/reel/CxXxXxXxXxX/",  // Reel
    "https://www.instagram.com/p/CxXxXxXxXxX/",     // Post
    "https://www.instagram.com/stories/username/12345/", // Story
)
```

### Unit Tests

```kotlin
class InstagramApiTest {
    
    private lateinit var api: InstagramApi
    
    @Before
    fun setup() {
        api = InstagramApi()
    }
    
    @Test
    fun `test valid reel URL parsing`() = runBlocking {
        val url = "https://www.instagram.com/reel/CxXxXxXxXxX/"
        val result = api.fetchMediaInfo(url)
        
        assertEquals(MediaType.REEL, result.type)
        assertTrue(result.downloadUrls.isNotEmpty())
    }
    
    @Test(expected = Exception::class)
    fun `test invalid URL throws exception`() = runBlocking {
        val url = "https://invalid-url.com"
        api.fetchMediaInfo(url)
    }
}
```

## 📈 Performance Optimization

### 1. Caching

```kotlin
class CachedInstagramApi(private val api: InstagramApi) {
    
    private val cache = LruCache<String, MediaInfo>(100)
    
    suspend fun fetchMediaInfo(url: String): MediaInfo {
        cache.get(url)?.let { return it }
        
        val result = api.fetchMediaInfo(url)
        cache.put(url, result)
        return result
    }
}
```

### 2. Parallel Downloads

```kotlin
suspend fun downloadMultipleQualities(mediaInfo: MediaInfo) {
    coroutineScope {
        mediaInfo.downloadUrls.map { (quality, url) ->
            async {
                downloadFile(url, quality)
            }
        }.awaitAll()
    }
}
```

## 🐛 Error Handling

```kotlin
sealed class Result<out T> {
    data class Success<T>(val data: T) : Result<T>()
    data class Error(val message: String, val throwable: Throwable? = null) : Result<Nothing>()
    object Loading : Result<Nothing>()
}

suspend fun fetchMediaInfoSafe(url: String): Result<MediaInfo> {
    return try {
        Result.Loading
        val info = api.fetchMediaInfo(url)
        Result.Success(info)
    } catch (e: Exception) {
        Result.Error("Failed to fetch media: ${e.message}", e)
    }
}
```

## 📝 Final Checklist

Before deploying to production:

- [ ] API key stored securely (not in code)
- [ ] Error handling implemented
- [ ] Rate limiting configured
- [ ] User agent set properly
- [ ] Timeout values configured
- [ ] Offline mode handling
- [ ] Loading states shown
- [ ] Success/error feedback
- [ ] Analytics integration
- [ ] Crash reporting (Firebase Crashlytics)
- [ ] Terms of Service created
- [ ] Privacy Policy created
- [ ] Legal review completed
- [ ] App tested on multiple devices
- [ ] Performance optimized
- [ ] Release build tested

## 🎓 Resources

- [Instagram API Documentation](https://developers.facebook.com/docs/instagram-api)
- [RapidAPI Instagram Tools](https://rapidapi.com/search/instagram)
- [OkHttp Documentation](https://square.github.io/okhttp/)
- [Kotlin Coroutines Guide](https://kotlinlang.org/docs/coroutines-guide.html)

---

**Good luck with your implementation! 🚀**
