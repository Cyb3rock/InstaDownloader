package com.instadownloader.models

enum class MediaType {
    REEL,
    POST,
    STORY
}

data class MediaInfo(
    val type: MediaType,
    val downloadUrls: Map<String, String>, // Quality -> URL mapping
    val availableQualities: List<String>,
    val thumbnailUrl: String = "",
    val isVideo: Boolean = true,
    val selectedQuality: String = "1080p",
    val username: String = "",
    val caption: String = ""
)
