package com.instadownloader

import android.Manifest
import android.animation.ObjectAnimator
import android.app.DownloadManager
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.instadownloader.databinding.ActivityMainBinding
import com.instadownloader.models.MediaInfo
import com.instadownloader.models.MediaType
import com.instadownloader.network.InstagramApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivityMainBinding
    private val instagramApi = InstagramApi()
    private var currentMediaInfo: MediaInfo? = null
    
    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            currentMediaInfo?.let { downloadMedia(it) }
        } else {
            showError("Storage permission is required to download media")
        }
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        setupUI()
        setupClickListeners()
        animateEntrance()
    }
    
    private fun setupUI() {
        // Set initial states
        binding.progressBar.visibility = View.GONE
        binding.downloadButton.isEnabled = false
        binding.mediaPreview.visibility = View.GONE
        binding.resolutionSelector.visibility = View.GONE
    }
    
    private fun setupClickListeners() {
        binding.fetchButton.setOnClickListener {
            val url = binding.urlInput.text.toString().trim()
            if (url.isNotEmpty()) {
                fetchMediaInfo(url)
            } else {
                animateShake(binding.urlInputLayout)
                showError("Please enter a valid Instagram URL")
            }
        }
        
        binding.downloadButton.setOnClickListener {
            currentMediaInfo?.let { mediaInfo ->
                val selectedResolution = when (binding.resolutionChipGroup.checkedChipId) {
                    binding.chip480p.id -> "480p"
                    binding.chip720p.id -> "720p"
                    binding.chip1080p.id -> "1080p"
                    binding.chip4k.id -> "4K"
                    else -> "1080p"
                }
                
                val mediaToDownload = mediaInfo.copy(selectedQuality = selectedResolution)
                checkPermissionAndDownload(mediaToDownload)
            }
        }
        
        binding.pasteButton.setOnClickListener {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
            val clipData = clipboard.primaryClip
            if (clipData != null && clipData.itemCount > 0) {
                val text = clipData.getItemAt(0).text.toString()
                binding.urlInput.setText(text)
                animatePulse(binding.urlInputLayout)
            }
        }
        
        binding.clearButton.setOnClickListener {
            clearAll()
        }
    }
    
    private fun fetchMediaInfo(url: String) {
        if (!isValidInstagramUrl(url)) {
            animateShake(binding.urlInputLayout)
            showError("Invalid Instagram URL. Please enter a valid Reel, Post, or Story URL")
            return
        }
        
        showLoading(true)
        animatePulse(binding.fetchButton)
        
        lifecycleScope.launch {
            try {
                val mediaInfo = withContext(Dispatchers.IO) {
                    instagramApi.fetchMediaInfo(url)
                }
                
                currentMediaInfo = mediaInfo
                displayMediaInfo(mediaInfo)
                showLoading(false)
                
            } catch (e: Exception) {
                showLoading(false)
                showError("Failed to fetch media: ${e.message}")
                animateShake(binding.contentCard)
            }
        }
    }
    
    private fun displayMediaInfo(mediaInfo: MediaInfo) {
        binding.apply {
            // Animate content reveal
            mediaPreview.visibility = View.VISIBLE
            resolutionSelector.visibility = View.VISIBLE
            downloadButton.isEnabled = true
            
            animateSlideIn(mediaPreview)
            animateSlideIn(resolutionSelector)
            animateSlideIn(downloadButton)
            
            // Set media type icon and text
            when (mediaInfo.type) {
                MediaType.REEL -> {
                    mediaTypeIcon.setImageResource(R.drawable.ic_reel)
                    mediaTypeText.text = "Instagram Reel"
                }
                MediaType.POST -> {
                    mediaTypeIcon.setImageResource(R.drawable.ic_post)
                    mediaTypeText.text = "Instagram Post"
                }
                MediaType.STORY -> {
                    mediaTypeIcon.setImageResource(R.drawable.ic_story)
                    mediaTypeText.text = "Instagram Story"
                }
            }
            
            // Set available resolutions
            chip480p.isEnabled = mediaInfo.availableQualities.contains("480p")
            chip720p.isEnabled = mediaInfo.availableQualities.contains("720p")
            chip1080p.isEnabled = mediaInfo.availableQualities.contains("1080p")
            chip4k.isEnabled = mediaInfo.availableQualities.contains("4K")
            
            // Select best available quality by default
            when {
                chip4k.isEnabled -> chip4k.isChecked = true
                chip1080p.isEnabled -> chip1080p.isChecked = true
                chip720p.isEnabled -> chip720p.isChecked = true
                else -> chip480p.isChecked = true
            }
            
            // Load thumbnail if available
            if (mediaInfo.thumbnailUrl.isNotEmpty()) {
                loadThumbnail(mediaInfo.thumbnailUrl)
            }
        }
    }
    
    private fun checkPermissionAndDownload(mediaInfo: MediaInfo) {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
            // Android 10+ doesn't need storage permission for downloads
            downloadMedia(mediaInfo)
        } else {
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE
                ) == PackageManager.PERMISSION_GRANTED
            ) {
                downloadMedia(mediaInfo)
            } else {
                requestPermissionLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            }
        }
    }
    
    private fun downloadMedia(mediaInfo: MediaInfo) {
        try {
            val downloadUrl = getDownloadUrlForQuality(mediaInfo)
            val fileName = generateFileName(mediaInfo)
            
            val request = DownloadManager.Request(Uri.parse(downloadUrl)).apply {
                setTitle("Instagram ${mediaInfo.type.name}")
                setDescription("Downloading ${mediaInfo.selectedQuality} quality")
                setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                setDestinationInExternalPublicDir(
                    Environment.DIRECTORY_DOWNLOADS,
                    "InstaDownloader/$fileName"
                )
                setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI or DownloadManager.Request.NETWORK_MOBILE)
            }
            
            val downloadManager = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            downloadManager.enqueue(request)
            
            animateSuccess(binding.downloadButton)
            showSuccess("Download started! Check your Downloads folder")
            
        } catch (e: Exception) {
            showError("Failed to start download: ${e.message}")
            animateShake(binding.downloadButton)
        }
    }
    
    private fun getDownloadUrlForQuality(mediaInfo: MediaInfo): String {
        // This would normally select the appropriate URL based on quality
        // For now, returning the main URL
        return mediaInfo.downloadUrls[mediaInfo.selectedQuality] ?: mediaInfo.downloadUrls.values.first()
    }
    
    private fun generateFileName(mediaInfo: MediaInfo): String {
        val timestamp = System.currentTimeMillis()
        val extension = if (mediaInfo.type == MediaType.POST && !mediaInfo.isVideo) ".jpg" else ".mp4"
        return "instagram_${mediaInfo.type.name.lowercase()}_${mediaInfo.selectedQuality}_$timestamp$extension"
    }
    
    private fun loadThumbnail(url: String) {
        // Use Glide or Coil to load thumbnail
        // Placeholder implementation
    }
    
    private fun isValidInstagramUrl(url: String): Boolean {
        return url.contains("instagram.com") && 
               (url.contains("/reel/") || url.contains("/p/") || url.contains("/stories/"))
    }
    
    private fun clearAll() {
        binding.apply {
            urlInput.text?.clear()
            mediaPreview.visibility = View.GONE
            resolutionSelector.visibility = View.GONE
            downloadButton.isEnabled = false
            currentMediaInfo = null
            animateFadeOut(mediaPreview)
            animateFadeOut(resolutionSelector)
        }
    }
    
    private fun showLoading(show: Boolean) {
        binding.progressBar.visibility = if (show) View.VISIBLE else View.GONE
        binding.fetchButton.isEnabled = !show
        
        if (show) {
            animatePulse(binding.progressBar)
        }
    }
    
    private fun showError(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }
    
    private fun showSuccess(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
    
    // Animation functions
    private fun animateEntrance() {
        binding.appTitle.alpha = 0f
        binding.appTitle.translationY = -50f
        binding.appTitle.animate()
            .alpha(1f)
            .translationY(0f)
            .setDuration(600)
            .setInterpolator(AccelerateDecelerateInterpolator())
            .start()
        
        binding.contentCard.alpha = 0f
        binding.contentCard.scaleX = 0.9f
        binding.contentCard.scaleY = 0.9f
        binding.contentCard.animate()
            .alpha(1f)
            .scaleX(1f)
            .scaleY(1f)
            .setStartDelay(200)
            .setDuration(500)
            .setInterpolator(AccelerateDecelerateInterpolator())
            .start()
    }
    
    private fun animateShake(view: View) {
        ObjectAnimator.ofFloat(view, "translationX", 0f, 25f, -25f, 25f, -25f, 15f, -15f, 6f, -6f, 0f).apply {
            duration = 500
            start()
        }
    }
    
    private fun animatePulse(view: View) {
        view.animate()
            .scaleX(1.05f)
            .scaleY(1.05f)
            .setDuration(150)
            .withEndAction {
                view.animate()
                    .scaleX(1f)
                    .scaleY(1f)
                    .setDuration(150)
                    .start()
            }
            .start()
    }
    
    private fun animateSlideIn(view: View) {
        view.alpha = 0f
        view.translationY = 30f
        view.animate()
            .alpha(1f)
            .translationY(0f)
            .setDuration(400)
            .setInterpolator(AccelerateDecelerateInterpolator())
            .start()
    }
    
    private fun animateFadeOut(view: View) {
        view.animate()
            .alpha(0f)
            .setDuration(300)
            .withEndAction {
                view.visibility = View.GONE
                view.alpha = 1f
            }
            .start()
    }
    
    private fun animateSuccess(view: View) {
        view.animate()
            .scaleX(1.1f)
            .scaleY(1.1f)
            .setDuration(200)
            .withEndAction {
                view.animate()
                    .scaleX(1f)
                    .scaleY(1f)
                    .setDuration(200)
                    .start()
            }
            .start()
    }
}
