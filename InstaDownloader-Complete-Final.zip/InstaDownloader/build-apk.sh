#!/bin/bash

# InstaDownloader APK Build Script
# This script automates the APK building process

echo "════════════════════════════════════════════════════════"
echo "  📱 InstaDownloader APK Builder"
echo "════════════════════════════════════════════════════════"
echo ""

# Color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

# Check if we're in the right directory
if [ ! -f "settings.gradle" ]; then
    print_error "Please run this script from the InstaDownloader project root directory"
    exit 1
fi

print_status "Checking prerequisites..."

# Check for required files
missing_files=()

# Check fonts
if [ ! -d "app/src/main/res/font" ]; then
    missing_files+=("Font folder (app/src/main/res/font/)")
fi

# Check XML files
if [ ! -f "app/src/main/res/xml/file_paths.xml" ]; then
    missing_files+=("app/src/main/res/xml/file_paths.xml")
fi

if [ ! -f "app/src/main/res/xml/backup_rules.xml" ]; then
    missing_files+=("app/src/main/res/xml/backup_rules.xml")
fi

if [ ! -f "app/src/main/res/xml/data_extraction_rules.xml" ]; then
    missing_files+=("app/src/main/res/xml/data_extraction_rules.xml")
fi

# If files are missing, show warning
if [ ${#missing_files[@]} -gt 0 ]; then
    print_warning "Missing required files:"
    for file in "${missing_files[@]}"; do
        echo "  - $file"
    done
    echo ""
    print_warning "The build may fail. See SETUP_CHECKLIST.md for details."
    echo ""
    read -p "Continue anyway? (y/n) " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
fi

# Make gradlew executable
print_status "Making gradlew executable..."
chmod +x gradlew

# Menu for build type
echo ""
echo "Select build type:"
echo "1) Debug APK (for testing, includes debugging info)"
echo "2) Release APK (optimized, smaller size)"
echo ""
read -p "Enter choice (1 or 2): " choice

case $choice in
    1)
        print_status "Building Debug APK..."
        ./gradlew assembleDebug
        
        if [ $? -eq 0 ]; then
            print_success "Debug APK built successfully!"
            APK_PATH="app/build/outputs/apk/debug/app-debug.apk"
            
            if [ -f "$APK_PATH" ]; then
                APK_SIZE=$(du -h "$APK_PATH" | cut -f1)
                echo ""
                print_success "APK Details:"
                echo "  📍 Location: $APK_PATH"
                echo "  📦 Size: $APK_SIZE"
                echo ""
                print_status "You can now install this APK on your Android device!"
                
                # Offer to open folder
                read -p "Open output folder? (y/n) " -n 1 -r
                echo
                if [[ $REPLY =~ ^[Yy]$ ]]; then
                    if [[ "$OSTYPE" == "darwin"* ]]; then
                        open "app/build/outputs/apk/debug/"
                    elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
                        xdg-open "app/build/outputs/apk/debug/"
                    elif [[ "$OSTYPE" == "msys" ]] || [[ "$OSTYPE" == "win32" ]]; then
                        explorer "app\\build\\outputs\\apk\\debug\\"
                    fi
                fi
            fi
        else
            print_error "Build failed! Check the error messages above."
            exit 1
        fi
        ;;
    2)
        print_warning "Release builds require signing configuration."
        print_status "Have you configured signing in app/build.gradle? (y/n)"
        read -p "" -n 1 -r
        echo
        
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            print_error "Please configure signing first. See BUILD_APK_GUIDE.md"
            exit 1
        fi
        
        print_status "Building Release APK..."
        ./gradlew assembleRelease
        
        if [ $? -eq 0 ]; then
            print_success "Release APK built successfully!"
            APK_PATH="app/build/outputs/apk/release/app-release.apk"
            
            if [ -f "$APK_PATH" ]; then
                APK_SIZE=$(du -h "$APK_PATH" | cut -f1)
                echo ""
                print_success "APK Details:"
                echo "  📍 Location: $APK_PATH"
                echo "  📦 Size: $APK_SIZE"
                echo "  🔒 Signed: Yes"
                echo ""
                print_status "This APK is ready for distribution!"
                
                # Offer to open folder
                read -p "Open output folder? (y/n) " -n 1 -r
                echo
                if [[ $REPLY =~ ^[Yy]$ ]]; then
                    if [[ "$OSTYPE" == "darwin"* ]]; then
                        open "app/build/outputs/apk/release/"
                    elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
                        xdg-open "app/build/outputs/apk/release/"
                    elif [[ "$OSTYPE" == "msys" ]] || [[ "$OSTYPE" == "win32" ]]; then
                        explorer "app\\build\\outputs\\apk\\release\\"
                    fi
                fi
            fi
        else
            print_error "Build failed! Check the error messages above."
            exit 1
        fi
        ;;
    *)
        print_error "Invalid choice"
        exit 1
        ;;
esac

echo ""
print_success "Build process complete!"
echo ""
echo "Next steps:"
echo "  1. Install the APK on your Android device"
echo "  2. Test all features"
echo "  3. Share with friends or publish to Play Store"
echo ""
echo "════════════════════════════════════════════════════════"
