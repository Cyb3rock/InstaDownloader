# Contributing to InstaDownloader

First off, thank you for considering contributing to InstaDownloader! 🎉

## Code of Conduct

This project and everyone participating in it is governed by our commitment to creating a welcoming and inclusive environment. Be respectful and constructive in all interactions.

## How Can I Contribute?

### Reporting Bugs

Before creating bug reports, please check existing issues to avoid duplicates. When you create a bug report, include as many details as possible:

- **Use a clear and descriptive title**
- **Describe the exact steps to reproduce the problem**
- **Provide specific examples**
- **Describe the behavior you observed and what you expected**
- **Include screenshots if applicable**
- **Include your Android version and device model**

### Suggesting Enhancements

Enhancement suggestions are tracked as GitHub issues. When creating an enhancement suggestion, include:

- **Use a clear and descriptive title**
- **Provide a step-by-step description of the suggested enhancement**
- **Provide specific examples to demonstrate the steps**
- **Describe the current behavior and explain the behavior you expected**
- **Explain why this enhancement would be useful**

### Pull Requests

1. Fork the repo and create your branch from `main`
2. If you've added code that should be tested, add tests
3. If you've changed APIs, update the documentation
4. Ensure the test suite passes
5. Make sure your code follows the existing code style
6. Write a clear commit message

## Development Setup

1. Clone the repository
```bash
git clone https://github.com/yourusername/InstaDownloader.git
cd InstaDownloader
```

2. Open in Android Studio
```bash
# Open Android Studio and select "Open an Existing Project"
# Navigate to the cloned directory
```

3. Add required resources (see SETUP_CHECKLIST.md)
   - Poppins fonts
   - Vector drawables
   - XML configuration files

4. Configure API integration (see IMPLEMENTATION_GUIDE.md)

5. Build and run
```bash
./gradlew build
./gradlew installDebug
```

## Code Style

- Follow [Kotlin Coding Conventions](https://kotlinlang.org/docs/coding-conventions.html)
- Use meaningful variable and function names
- Add comments for complex logic
- Keep functions small and focused
- Use ViewBinding instead of findViewById
- Use Kotlin Coroutines for async operations

## Git Commit Messages

- Use the present tense ("Add feature" not "Added feature")
- Use the imperative mood ("Move cursor to..." not "Moves cursor to...")
- Limit the first line to 72 characters or less
- Reference issues and pull requests liberally after the first line

### Examples:
```
Add batch download functionality

Implement the ability to download multiple Instagram posts
at once. Closes #123

- Add batch download UI
- Implement parallel download logic
- Add progress tracking
```

## Project Structure

```
app/src/main/
├── java/com/instadownloader/
│   ├── MainActivity.kt          # Main app activity
│   ├── models/                  # Data models
│   └── network/                 # API and networking
└── res/
    ├── layout/                  # XML layouts
    ├── values/                  # Colors, strings, themes
    └── drawable/                # Icons and graphics
```

## Testing

- Write unit tests for new functionality
- Test on multiple Android versions (min API 24, target API 34)
- Test on different screen sizes
- Test with various Instagram content types

## Areas for Contribution

### High Priority
- [ ] Real API integration examples
- [ ] Download history feature
- [ ] Batch download support
- [ ] Dark mode implementation
- [ ] Video preview feature

### Medium Priority
- [ ] Multiple language support (i18n)
- [ ] Share functionality
- [ ] Custom download location
- [ ] Download queue management
- [ ] Better error messages

### Low Priority
- [ ] App themes/customization
- [ ] Download statistics
- [ ] Export/Import settings
- [ ] Widget support

## Documentation

- Update README.md for any new features
- Add comments to complex code
- Update IMPLEMENTATION_GUIDE.md for API changes
- Keep SETUP_CHECKLIST.md current

## Questions?

Feel free to open an issue with the question tag, or reach out to the maintainers.

## License

By contributing, you agree that your contributions will be licensed under the MIT License.

---

Thank you for contributing to InstaDownloader! 🚀
