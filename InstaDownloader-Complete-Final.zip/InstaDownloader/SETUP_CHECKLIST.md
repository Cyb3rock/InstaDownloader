# Quick Setup Checklist

Use this checklist to ensure your Instagram Downloader app is properly configured.

## ✅ Essential Setup Steps

### 1. Fonts (REQUIRED)
- [ ] Create folder: `app/src/main/res/font/`
- [ ] Download Poppins font from Google Fonts
- [ ] Add these files:
  - [ ] `poppins_regular.ttf`
  - [ ] `poppins_medium.ttf`
  - [ ] `poppins_semibold.ttf`
  - [ ] `poppins_bold.ttf`

**Download Link**: https://fonts.google.com/specimen/Poppins

### 2. Icons/Drawables (REQUIRED)
Create these vector drawables in `app/src/main/res/drawable/`:

- [ ] `ic_instagram.xml` - App logo
- [ ] `ic_reel.xml` - Reel icon
- [ ] `ic_post.xml` - Post icon  
- [ ] `ic_story.xml` - Story icon
- [ ] `ic_link.xml` - Link/URL icon
- [ ] `ic_paste.xml` - Paste icon
- [ ] `ic_clear.xml` - Clear/delete icon
- [ ] `ic_download.xml` - Download icon
- [ ] `ic_download_cloud.xml` - Cloud download icon
- [ ] `ic_check_circle.xml` - Success checkmark

**Tip**: Use Material Icons or create your own in Android Studio:
- Right-click `drawable` → New → Vector Asset → Clip Art

### 3. XML Configuration Files (REQUIRED)
Create in `app/src/main/res/xml/`:

- [ ] `file_paths.xml`
```xml
<?xml version="1.0" encoding="utf-8"?>
<paths>
    <external-files-path name="downloads" path="Downloads/" />
    <external-path name="external_files" path="." />
</paths>
```

- [ ] `backup_rules.xml`
```xml
<?xml version="1.0" encoding="utf-8"?>
<full-backup-content>
    <include domain="sharedpref" path="." />
</full-backup-content>
```

- [ ] `data_extraction_rules.xml`
```xml
<?xml version="1.0" encoding="utf-8"?>
<data-extraction-rules>
    <cloud-backup>
        <include domain="sharedpref" path="." />
    </cloud-backup>
</data-extraction-rules>
```

### 4. API Integration (CRITICAL)
Choose ONE option and implement:

- [ ] **Option A**: RapidAPI (Easiest)
  - Sign up at https://rapidapi.com
  - Subscribe to Instagram Downloader API
  - Add API key to `gradle.properties`
  - Update `InstagramApi.kt`

- [ ] **Option B**: Custom Backend
  - Deploy Python/Node.js backend
  - Update API endpoint in code
  
- [ ] **Option C**: Instagram Graph API
  - Create Facebook Developer account
  - Create Instagram app
  - Implement OAuth flow

### 5. App Icon (RECOMMENDED)
- [ ] Create app icon (1024x1024 PNG)
- [ ] Use Image Asset Studio in Android Studio:
  - Right-click `res` → New → Image Asset
- [ ] Generate adaptive icons for all densities

### 6. Testing (REQUIRED)
- [ ] Test on Android 7.0 (API 24) minimum
- [ ] Test on Android 14 (API 34) target
- [ ] Test with different Instagram URLs:
  - [ ] Public Reel
  - [ ] Public Post
  - [ ] Public Story
  - [ ] Private content (should fail gracefully)
  - [ ] Invalid URL (should show error)

### 7. Build Configuration
- [ ] Sync Gradle successfully
- [ ] No build errors
- [ ] ProGuard rules configured
- [ ] App runs on emulator
- [ ] App runs on physical device

### 8. Release Preparation (OPTIONAL)
- [ ] Create keystore for signing
- [ ] Configure signing in build.gradle
- [ ] Test release build
- [ ] Optimize app size
- [ ] Add Privacy Policy
- [ ] Add Terms of Service

## 🚀 Quick Start Commands

```bash
# Clone or create project
cd InstaDownloader

# Sync Gradle
./gradlew build

# Run on connected device
./gradlew installDebug

# Create release APK
./gradlew assembleRelease
```

## 📱 Test URLs

Use these for testing (replace with actual Instagram URLs):

```
Reel: https://www.instagram.com/reel/[shortcode]/
Post: https://www.instagram.com/p/[shortcode]/
Story: https://www.instagram.com/stories/[username]/[storyid]/
```

## ⚠️ Common Issues

### "Cannot resolve symbol R"
**Solution**: Rebuild project (Build → Rebuild Project)

### "Font resource not found"
**Solution**: Ensure fonts are in `res/font/` folder with correct names

### "API returns error"
**Solution**: Verify API key is correct and has active subscription

### "Download not starting"
**Solution**: Check storage permissions are granted

### "Gradle sync failed"
**Solution**: 
- Update Android Studio
- File → Invalidate Caches / Restart
- Check internet connection

## 📞 Need Help?

1. Check README.md for detailed instructions
2. Check IMPLEMENTATION_GUIDE.md for API integration
3. Review error messages carefully
4. Test on different devices/Android versions

---

**Once you complete all required items, your app is ready for testing! 🎉**
