# GitHub Upload Guide

This guide will help you upload your InstaDownloader project to GitHub.

## 📋 Prerequisites

1. **GitHub Account** - Create one at https://github.com if you don't have one
2. **Git Installed** - Download from https://git-scm.com/downloads
3. **Project Ready** - Complete the setup checklist first

## 🚀 Method 1: Upload via GitHub Web Interface (Easiest)

### Step 1: Create a New Repository

1. Go to https://github.com
2. Click the **"+"** icon in the top right
3. Select **"New repository"**
4. Fill in the details:
   - **Repository name**: `InstaDownloader` or `instagram-media-downloader`
   - **Description**: `A beautiful Android app for downloading Instagram Reels, Posts, and Stories with multiple quality options`
   - **Visibility**: Choose Public or Private
   - **DO NOT** initialize with README (we already have one)
5. Click **"Create repository"**

### Step 2: Upload Files

**Option A: Drag and Drop (Simple)**
1. On your new repository page, click **"uploading an existing file"**
2. Drag the entire `InstaDownloader` folder
3. Wait for upload to complete
4. Add commit message: "Initial commit - InstaDownloader v1.0.0"
5. Click **"Commit changes"**

**Option B: Use ZIP file**
1. Extract the InstaDownloader folder from the ZIP
2. Go to your repository page
3. Click **"Add file"** → **"Upload files"**
4. Drag all files and folders from InstaDownloader
5. Commit the changes

### Step 3: Add Topics (Optional but Recommended)

1. On your repository page, click the ⚙️ icon next to "About"
2. Add topics: `android`, `kotlin`, `instagram`, `downloader`, `material-design`, `instagram-downloader`
3. Save changes

## 🚀 Method 2: Upload via Git Command Line (Recommended)

### Step 1: Create Repository on GitHub

Follow Step 1 from Method 1 above.

### Step 2: Initialize Local Repository

Open terminal/command prompt in the InstaDownloader folder:

```bash
# Navigate to your project
cd path/to/InstaDownloader

# Initialize git repository
git init

# Add all files
git add .

# Create first commit
git commit -m "Initial commit - InstaDownloader v1.0.0"

# Rename branch to main (if needed)
git branch -M main

# Add remote repository (replace YOUR_USERNAME with your GitHub username)
git remote add origin https://github.com/YOUR_USERNAME/InstaDownloader.git

# Push to GitHub
git push -u origin main
```

### Step 3: Enter Credentials

- Enter your GitHub username
- For password, use a **Personal Access Token** (not your regular password)

#### How to Create Personal Access Token:
1. Go to GitHub Settings → Developer settings → Personal access tokens → Tokens (classic)
2. Click "Generate new token"
3. Select scopes: `repo` (full control of private repositories)
4. Copy the token and save it securely
5. Use this token as your password when pushing

## 🔐 Protecting API Keys

**CRITICAL**: Before uploading, ensure you've secured your API keys!

### Create gradle.properties.template

Create a template file showing what keys are needed:

```bash
# In your project root, create gradle.properties.template
cat > gradle.properties.template << EOF
# Copy this file to gradle.properties and fill in your actual keys
# DO NOT commit gradle.properties to version control!

# RapidAPI Key (Get from https://rapidapi.com)
RAPID_API_KEY=your_api_key_here

# Other API keys as needed
# INSTAGRAM_APP_ID=your_app_id_here
# INSTAGRAM_APP_SECRET=your_app_secret_here
EOF
```

### Verify .gitignore

Make sure your `.gitignore` includes:
```
gradle.properties
*.jks
*.keystore
google-services.json
```

## 📝 Writing a Great README

Your README.md is already excellent! Here are some additions for GitHub:

### Add Badges (Optional)

Add these at the top of README.md:

```markdown
# InstaDownloader

![Android](https://img.shields.io/badge/Android-7.0+-brightgreen)
![Kotlin](https://img.shields.io/badge/Kotlin-1.9.22-blue)
![Material Design 3](https://img.shields.io/badge/Material%20Design-3-orange)
![License](https://img.shields.io/badge/License-MIT-yellow)
```

### Add Download Link

After your first release:

```markdown
## Download

[![Download APK](https://img.shields.io/badge/Download-APK-brightgreen)](https://github.com/YOUR_USERNAME/InstaDownloader/releases/latest)
```

## 📦 Creating Releases

### Step 1: Build Release APK

```bash
# Clean and build release
./gradlew clean assembleRelease

# APK will be in: app/build/outputs/apk/release/
```

### Step 2: Create Release on GitHub

1. Go to your repository
2. Click **"Releases"** on the right sidebar
3. Click **"Create a new release"**
4. Fill in:
   - **Tag**: `v1.0.0`
   - **Title**: `InstaDownloader v1.0.0 - Initial Release`
   - **Description**: 
   ```markdown
   ## 🎉 First Release!
   
   ### Features
   - ✨ Beautiful Material Design 3 UI
   - 📱 Download Instagram Reels, Posts, and Stories
   - 🎯 Multiple quality options (480p - 4K)
   - 💫 Smooth animations throughout
   - 🔒 Secure and safe
   
   ### Installation
   1. Download the APK below
   2. Enable "Install from Unknown Sources"
   3. Install and enjoy!
   
   ### Setup Required
   See [SETUP_CHECKLIST.md](SETUP_CHECKLIST.md) for first-time setup.
   ```
5. Upload your release APK
6. Click **"Publish release"**

## 🎨 Adding Screenshots

Make your repository look professional:

### Step 1: Create Screenshots

Run your app and take screenshots:
- Main screen
- Media preview
- Quality selection
- Download in progress
- Downloaded media

### Step 2: Add to Repository

1. Create folder: `screenshots/`
2. Upload your screenshots
3. Update README.md:

```markdown
## Screenshots

<p align="center">
  <img src="screenshots/main_screen.png" width="250" />
  <img src="screenshots/quality_selection.png" width="250" />
  <img src="screenshots/downloading.png" width="250" />
</p>
```

## 🌟 Repository Settings

### Enable Features

Go to Settings → General:
- ✅ Issues (for bug reports)
- ✅ Wiki (for documentation)
- ✅ Discussions (for community)

### Add Description

- Description: `A beautiful Android app for downloading Instagram Reels, Posts, and Stories with multiple quality options 📱✨`
- Website: Your website or blog (if you have one)
- Topics: `android`, `kotlin`, `instagram`, `downloader`, `material-design`

### Set Up Branch Protection (Optional)

Settings → Branches → Add rule:
- Branch name pattern: `main`
- ✅ Require pull request reviews before merging
- ✅ Require status checks to pass

## 📊 Project Board (Optional)

Organize your work:

1. Go to Projects tab
2. Create new project
3. Add columns: To Do, In Progress, Done
4. Link issues and PRs

## 🤝 Community Files

Already included:
- ✅ LICENSE (MIT)
- ✅ CONTRIBUTING.md
- ✅ .github/ISSUE_TEMPLATE/
- ✅ .github/workflows/ (CI/CD)

## 📢 Promoting Your Project

### Add to Lists
- [Awesome Android](https://github.com/JStumpp/awesome-android)
- [Android Arsenal](https://android-arsenal.com/free)
- Reddit: r/androiddev, r/Android

### Social Media
Tweet about it with hashtags:
- #AndroidDev
- #Kotlin
- #MaterialDesign
- #OpenSource

### Write a Blog Post
Share your development journey!

## 🔄 Updating Your Repository

### Make Changes Locally

```bash
# Make your changes
git add .
git commit -m "Add dark mode support"
git push origin main
```

### Create Feature Branches

```bash
# Create new branch
git checkout -b feature/dark-mode

# Make changes and commit
git add .
git commit -m "Implement dark mode"

# Push branch
git push origin feature/dark-mode

# Create Pull Request on GitHub
```

## ⚠️ Important Reminders

### DO:
- ✅ Keep your API keys secret
- ✅ Use .gitignore properly
- ✅ Write clear commit messages
- ✅ Respond to issues promptly
- ✅ Welcome contributors
- ✅ Keep README updated

### DON'T:
- ❌ Commit API keys or secrets
- ❌ Commit keystore files
- ❌ Commit build/ or .gradle/ folders
- ❌ Commit local.properties
- ❌ Push without testing

## 🆘 Troubleshooting

### "Failed to push"
```bash
# Pull latest changes first
git pull origin main
# Resolve conflicts if any
git push origin main
```

### "Authentication failed"
- Use Personal Access Token, not password
- Check token has correct permissions

### "Large files"
- Remove from commits: `git rm --cached large_file.apk`
- Add to .gitignore
- Commit and push again

### "Merge conflicts"
```bash
# See conflicting files
git status

# Edit files to resolve conflicts
# Then:
git add .
git commit -m "Resolve merge conflicts"
git push
```

## 📚 Resources

- [GitHub Guides](https://guides.github.com/)
- [Git Documentation](https://git-scm.com/doc)
- [Markdown Guide](https://www.markdownguide.org/)
- [GitHub Actions](https://docs.github.com/en/actions)

## ✅ Final Checklist

Before making repository public:

- [ ] All API keys removed from code
- [ ] .gitignore properly configured
- [ ] README.md is complete and accurate
- [ ] LICENSE file is present
- [ ] CONTRIBUTING.md is clear
- [ ] Code is tested and working
- [ ] Screenshots added (optional)
- [ ] Release APK created (optional)
- [ ] Repository description and topics set
- [ ] Issue templates configured

## 🎉 Congratulations!

Your InstaDownloader app is now on GitHub! 

**Repository URL**: `https://github.com/YOUR_USERNAME/InstaDownloader`

Share it with the world! 🌍

---

**Need Help?** 
- GitHub Support: https://support.github.com/
- Git Help: `git --help`
- Community: GitHub Discussions tab
