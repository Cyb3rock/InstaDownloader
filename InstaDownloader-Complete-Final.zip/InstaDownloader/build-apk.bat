@echo off
REM InstaDownloader APK Build Script for Windows
REM This script automates the APK building process

echo ========================================================
echo   InstaDownloader APK Builder (Windows)
echo ========================================================
echo.

REM Check if we're in the right directory
if not exist "settings.gradle" (
    echo [ERROR] Please run this script from the InstaDownloader project root directory
    pause
    exit /b 1
)

echo [INFO] Checking prerequisites...

REM Check for required files
set MISSING=0

if not exist "app\src\main\res\font" (
    echo [WARNING] Missing: Font folder
    set MISSING=1
)

if not exist "app\src\main\res\xml\file_paths.xml" (
    echo [WARNING] Missing: file_paths.xml
    set MISSING=1
)

if not exist "app\src\main\res\xml\backup_rules.xml" (
    echo [WARNING] Missing: backup_rules.xml
    set MISSING=1
)

if not exist "app\src\main\res\xml\data_extraction_rules.xml" (
    echo [WARNING] Missing: data_extraction_rules.xml
    set MISSING=1
)

if %MISSING%==1 (
    echo.
    echo [WARNING] Some required files are missing.
    echo The build may fail. See SETUP_CHECKLIST.md for details.
    echo.
    set /p continue="Continue anyway? (Y/N): "
    if /i not "%continue%"=="Y" exit /b 1
)

echo.
echo Select build type:
echo 1) Debug APK (for testing)
echo 2) Release APK (for distribution)
echo.
set /p choice="Enter choice (1 or 2): "

if "%choice%"=="1" (
    echo.
    echo [INFO] Building Debug APK...
    call gradlew.bat assembleDebug
    
    if errorlevel 1 (
        echo.
        echo [ERROR] Build failed! Check the error messages above.
        pause
        exit /b 1
    )
    
    echo.
    echo [SUCCESS] Debug APK built successfully!
    echo.
    echo APK Location: app\build\outputs\apk\debug\app-debug.apk
    echo.
    
    set /p openfolder="Open output folder? (Y/N): "
    if /i "%openfolder%"=="Y" (
        explorer app\build\outputs\apk\debug
    )
    
) else if "%choice%"=="2" (
    echo.
    echo [WARNING] Release builds require signing configuration.
    set /p configured="Have you configured signing? (Y/N): "
    
    if /i not "%configured%"=="Y" (
        echo [ERROR] Please configure signing first. See BUILD_APK_GUIDE.md
        pause
        exit /b 1
    )
    
    echo.
    echo [INFO] Building Release APK...
    call gradlew.bat assembleRelease
    
    if errorlevel 1 (
        echo.
        echo [ERROR] Build failed! Check the error messages above.
        pause
        exit /b 1
    )
    
    echo.
    echo [SUCCESS] Release APK built successfully!
    echo.
    echo APK Location: app\build\outputs\apk\release\app-release.apk
    echo.
    
    set /p openfolder="Open output folder? (Y/N): "
    if /i "%openfolder%"=="Y" (
        explorer app\build\outputs\apk\release
    )
    
) else (
    echo [ERROR] Invalid choice
    pause
    exit /b 1
)

echo.
echo ========================================================
echo [SUCCESS] Build process complete!
echo ========================================================
echo.
pause
