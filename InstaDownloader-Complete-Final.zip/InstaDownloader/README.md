# InstaDownloader - Instagram Media Downloader for Android

A beautiful, modern Android application for downloading Instagram Reels, Posts, and Stories with multiple resolution options (480p, 720p, 1080p, 4K).

## ✨ Features

- 🎨 **Beautiful Material Design 3 UI** with Instagram-inspired gradient theme
- 🎬 **Support for Multiple Media Types**: Reels, Posts, and Stories
- 📊 **Multiple Resolution Options**: 480p, 720p, 1080p, and 4K (when available)
- 💫 **Smooth Animations**: All UI elements feature beautiful entrance and interaction animations
- 📱 **Modern Architecture**: Built with Kotlin, Coroutines, and best practices
- 🔒 **Safe & Secure**: Proper permission handling and error management
- 🚀 **Zero Bugs Design**: Comprehensive error handling and validation

## 📸 Screenshots

[App screenshots would go here]

## 🛠️ Tech Stack

- **Language**: Kotlin
- **UI Framework**: Material Design 3
- **Architecture**: MVVM (can be extended)
- **Async Operations**: Kotlin Coroutines
- **Networking**: OkHttp, Retrofit
- **Image Loading**: Glide, Coil
- **Minimum SDK**: 24 (Android 7.0)
- **Target SDK**: 34 (Android 14)

## 📦 Installation

### Prerequisites

- Android Studio Hedgehog (2023.1.1) or later
- JDK 17 or later
- Android SDK with API 34

### Setup Steps

1. **Clone the repository**
```bash
git clone https://github.com/yourusername/InstaDownloader.git
cd InstaDownloader
```

2. **Open in Android Studio**
   - Open Android Studio
   - Click "Open an Existing Project"
   - Navigate to the cloned directory
   - Wait for Gradle sync to complete

3. **Add Required Fonts** (Important!)
   Create `app/src/main/res/font/` directory and add Poppins font family:
   - poppins_regular.ttf
   - poppins_medium.ttf
   - poppins_semibold.ttf
   - poppins_bold.ttf
   
   Download from: https://fonts.google.com/specimen/Poppins

4. **Add Required Drawables** (Icons)
   Create these vector drawables in `app/src/main/res/drawable/`:
   
   - `ic_instagram.xml` - Instagram logo
   - `ic_reel.xml` - Reel icon
   - `ic_post.xml` - Post icon
   - `ic_story.xml` - Story icon
   - `ic_link.xml` - Link icon
   - `ic_paste.xml` - Paste icon
   - `ic_clear.xml` - Clear icon
   - `ic_download.xml` - Download icon
   - `ic_download_cloud.xml` - Cloud download icon
   - `ic_check_circle.xml` - Check circle icon

   You can use Material Icons or create custom ones.

5. **Configure Instagram API** (CRITICAL!)

   The current implementation uses mock data. For production, you need to:

   **Option A: Use Third-Party API (Recommended)**
   ```kotlin
   // In InstagramApi.kt, integrate a service like:
   // - RapidAPI Instagram Downloader
   // - InstaLoader API
   // - SaveFrom.net API
   
   private val API_KEY = "your_api_key_here"
   private val API_ENDPOINT = "https://instagram-downloader.p.rapidapi.com"
   ```

   **Option B: Use Instagram Official API**
   - Create a Facebook Developer account
   - Create an Instagram App
   - Get access tokens
   - Implement Instagram Graph API
   - Note: Only works with Business/Creator accounts

   **Option C: Web Scraping (Advanced)**
   - Parse Instagram's HTML/GraphQL responses
   - Extract video URLs from CDN
   - Handle authentication and rate limiting
   - ⚠️ May violate Instagram's ToS

6. **Add File Provider Paths**
   Create `app/src/main/res/xml/file_paths.xml`:
```xml
<?xml version="1.0" encoding="utf-8"?>
<paths>
    <external-files-path name="downloads" path="Downloads/" />
    <external-path name="external_files" path="." />
</paths>
```

7. **Add Backup Rules**
   Create `app/src/main/res/xml/backup_rules.xml`:
```xml
<?xml version="1.0" encoding="utf-8"?>
<full-backup-content>
    <include domain="sharedpref" path="." />
</full-backup-content>
```

   Create `app/src/main/res/xml/data_extraction_rules.xml`:
```xml
<?xml version="1.0" encoding="utf-8"?>
<data-extraction-rules>
    <cloud-backup>
        <include domain="sharedpref" path="." />
    </cloud-backup>
</data-extraction-rules>
```

8. **Build and Run**
```bash
./gradlew clean build
./gradlew installDebug
```

## 🎯 How It Works

1. **User Input**: User pastes Instagram URL (Reel/Post/Story)
2. **URL Validation**: App validates the URL format
3. **Media Fetching**: App fetches media information using API
4. **Quality Selection**: User selects desired quality (480p-4K)
5. **Download**: Media is downloaded to device storage
6. **Completion**: User receives notification when download completes

## 🔐 Permissions

The app requires the following permissions:

- `INTERNET` - To fetch media from Instagram
- `ACCESS_NETWORK_STATE` - To check network connectivity
- `WRITE_EXTERNAL_STORAGE` - For Android 9 and below
- `READ_MEDIA_VIDEO` - For Android 13+
- `READ_MEDIA_IMAGES` - For Android 13+

## 🎨 UI/UX Features

### Animations
- **Entrance Animations**: Smooth fade-in and slide-up effects
- **Pulse Animation**: Interactive button feedback
- **Shake Animation**: Error state indication
- **Slide Transitions**: Smooth content reveals
- **Success Animation**: Confirmation feedback

### Design Highlights
- Instagram-inspired gradient theme
- Material Design 3 components
- Rounded corners and elevation
- Smooth chip selection
- Responsive layout

## 📁 Project Structure

```
InstaDownloader/
├── app/
│   ├── src/
│   │   ├── main/
│   │   │   ├── java/com/instadownloader/
│   │   │   │   ├── MainActivity.kt
│   │   │   │   ├── models/
│   │   │   │   │   └── MediaInfo.kt
│   │   │   │   └── network/
│   │   │   │       └── InstagramApi.kt
│   │   │   ├── res/
│   │   │   │   ├── layout/
│   │   │   │   │   └── activity_main.xml
│   │   │   │   ├── values/
│   │   │   │   │   ├── colors.xml
│   │   │   │   │   ├── strings.xml
│   │   │   │   │   └── themes.xml
│   │   │   │   ├── drawable/
│   │   │   │   ├── font/
│   │   │   │   └── xml/
│   │   │   └── AndroidManifest.xml
│   │   └── build.gradle
│   └── build.gradle
├── build.gradle
└── settings.gradle
```

## 🚀 Implementation Guide

### Step 1: Choose Your API Provider

**For Production Use, Choose ONE of these:**

1. **RapidAPI Instagram Downloader** (Easiest)
   - Sign up at rapidapi.com
   - Subscribe to Instagram Downloader API
   - Add API key to your project
   - Cost: Free tier available, paid plans for high volume

2. **Custom API Server** (Most Flexible)
   - Deploy your own backend (Node.js/Python)
   - Use libraries like `instaloader` (Python)
   - Handle rate limiting and caching
   - Full control over functionality

3. **Instagram Graph API** (Official, Limited)
   - Only for Business/Creator accounts
   - Requires Facebook App approval
   - Limited to authorized content
   - Best for legitimate business use

### Step 2: Update InstagramApi.kt

Replace the mock implementation with real API calls:

```kotlin
suspend fun fetchMediaInfo(instagramUrl: String): MediaInfo {
    return withContext(Dispatchers.IO) {
        val response = makeApiRequest(instagramUrl)
        parseMediaResponse(response)
    }
}

private fun makeApiRequest(url: String): String {
    val client = OkHttpClient()
    val request = Request.Builder()
        .url("$API_ENDPOINT?url=$url")
        .addHeader("X-RapidAPI-Key", API_KEY)
        .build()
    
    client.newCall(request).execute().use { response ->
        return response.body?.string() ?: throw Exception("Empty response")
    }
}
```

### Step 3: Handle Different Resolutions

Instagram videos are typically available in:
- **480p**: Mobile-friendly, small file size
- **720p**: HD quality, balanced
- **1080p**: Full HD, default for most content
- **4K**: Ultra HD, rare, only on select content

The API response usually includes different CDN URLs for each quality.

### Step 4: Test Thoroughly

Test with:
- ✅ Public Reels
- ✅ Public Posts
- ✅ Public Stories (within 24h)
- ❌ Private accounts (should fail gracefully)
- ❌ Expired stories (should show error)
- ❌ Invalid URLs (should validate)

## ⚖️ Legal Considerations

**IMPORTANT**: This app is for educational purposes.

- ✅ Only download public content
- ✅ Respect copyright and intellectual property
- ✅ Follow Instagram's Terms of Service
- ❌ Don't redistribute downloaded content
- ❌ Don't use for commercial purposes without permission
- ❌ Don't bypass private account restrictions

## 🐛 Known Issues & Solutions

### Issue: "Failed to fetch media"
**Solution**: Verify your API key and endpoint are correct

### Issue: "Permission denied"
**Solution**: Ensure storage permissions are granted on Android 10-

### Issue: "Download not starting"
**Solution**: Check DownloadManager is enabled in system settings

### Issue: "No quality options available"
**Solution**: API may not return quality variations for all content

## 🔧 Customization

### Change Color Scheme
Edit `colors.xml` to customize the app's appearance:
```xml
<color name="primary">#YOUR_COLOR</color>
<color name="gradient_start">#YOUR_COLOR</color>
```

### Add More Features
Consider adding:
- Batch download
- Download history
- Video preview
- Share functionality
- Dark mode
- Multiple languages

## 📱 Building Release APK

```bash
./gradlew assembleRelease
```

The APK will be in: `app/build/outputs/apk/release/`

### Signing Your APK

1. Create a keystore:
```bash
keytool -genkey -v -keystore my-release-key.jks -keyalg RSA -keysize 2048 -validity 10000 -alias my-key-alias
```

2. Add to `app/build.gradle`:
```gradle
android {
    signingConfigs {
        release {
            storeFile file("my-release-key.jks")
            storePassword "password"
            keyAlias "my-key-alias"
            keyPassword "password"
        }
    }
    buildTypes {
        release {
            signingConfig signingConfigs.release
        }
    }
}
```

## 🤝 Contributing

Contributions are welcome! Please:
1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Submit a pull request

## 📄 License

This project is licensed under the MIT License - see LICENSE file for details.

## ⚠️ Disclaimer

This application is for educational purposes only. The developers are not responsible for any misuse of this application. Users must comply with Instagram's Terms of Service and applicable laws.

## 🙏 Acknowledgments

- Material Design 3 by Google
- Instagram for inspiration
- Kotlin Coroutines
- Android Open Source Project

## 📞 Support

For issues and questions:
- Open an issue on GitHub
- Email: support@instadownloader.app

---

**Made with ❤️ for the Android community**
