---
name: Bug Report
about: Create a report to help us improve
title: '[BUG] '
labels: bug
assignees: ''
---

## Bug Description
A clear and concise description of what the bug is.

## To Reproduce
Steps to reproduce the behavior:
1. Go to '...'
2. Click on '....'
3. Scroll down to '....'
4. See error

## Expected Behavior
A clear and concise description of what you expected to happen.

## Screenshots
If applicable, add screenshots to help explain your problem.

## Device Information
 - Device: [e.g. Pixel 7]
 - Android Version: [e.g. Android 14]
 - App Version: [e.g. 1.0.0]

## Instagram Content
- Content Type: [Reel/Post/Story]
- URL: [if applicable]
- Selected Quality: [480p/720p/1080p/4K]

## Additional Context
Add any other context about the problem here.

## Logs
If applicable, paste any error logs here:
```
Paste logcat output here
```
